/*Ejercicio numero 1*/
use pubs;

/*Ejercicio numero 2*/
SELECT * FROM pubs.authors;

/*Ejercicio numero 3*/
SELECT * FROM pubs.publishers;

/*Ejercicio numero 4*/
describe stores;

/*Ejercicio numero 5*/
describe sales;

/*Ejercicio numero 6*/
select emp_id as 'Numero de Empleado',
concat(fname," ", lname) as 'Nombre de Empleado',
hire_date as 'Fecha de Inicio' from employee 
where pub_id = 877;

/*Ejercicio numero 7*/
select
title as 'Titulo', 
price as 'Precio Bruto',
price * 21 as 'Precio IVA'
from  titles;

/*Ejercicio numero 8*/
select distinct type from titles;

/*Ejercicio numero 9*/
select distinct country from publishers;

/*Ejercicio numero 10*/
select distinct (city), (state) from authors;

/*Ejercicio numero 11*/
select concat(fname," ", lname) as 'Nombre de Empleado'
from employee
where pub_id = 877
order by job_lvl desc, hire_date asc;

/*Ejercicio numero 12*/
select au_id as 'Numero', au_lname as 'Apellido', au_fname as 'Nombre', phone as 'Telefono'
from authors
where state = 'CA' and contract = '0';

/*Ejercicio numero 13*/
select concat(fname," ", lname) as 'Nombre de Empleado', job_lvl as 'Nivel de Trabajo', hire_date as 'Fecha de Incorporación'
from employee
where hire_date like '1990%' and job_lvl between 100 and 200;

/*Ejercicio numero 14*/

select title_id as 'ID del titulo', qty as 'Cantidad de Venta' 
from sales
where payterms = 'ON invoice' and qty >= 13 and qty <= 40;


/*Ejercicio numero 15*/
SELECT pub_id as 'Numero', pub_name as 'Nombre de la Editorial'
FROM publishers
WHERE state is null;

/*Ejercicio numero 16*/

select title as 'Titulo', price as 'Precio'
from titles
where type like '%cook' and title not like 'sushi%'
order by price desc;


/*Ejercicio numero 17*/

select *
from employee
where fname like 'p%o' and lname like '%o' ;

/*Ejercicio numero 18*/

select *
from authors
where address like '%#%' and au_lname like '_r%';

/*Ejercicio numero 19*/

select *
from employee
where fname rlike '^[a,p][^a].*[h-z]$';

/*Ejercicio numero 20*/

select *
from sales
where payterms ='Net 30'and year (ord_date) in (1992,1993) 
or payterms = 'Net 60' and year(ord_date) = 1994 
and month(ord_date) between 7 and 12;

/*Ejercicio numero 21*/

select count(state) as 'Autores Californianos'
from authors
where state = 'CA';
 
 /*Ejercicio numero 22*/
 
 select min(ord_date) as inicio,
 max(ord_date) as cierre
 from sales;
 
 /*Ejercicio numero 23*/
 
select count(distinct country)
from publishers;

/*Ejercicio numero 24*/

select  type as 'categorias', 
		truncate(avg (price), 2) as 'promedio'
from titles
group by type;

/*Ejercicio numero 25*/

select  type as 'categorias', 
		truncate(avg (price), 2) as 'promedio'
from titles
where price is not null
group by type;

/*Ejercicio numero 26*/

select stor_id as locales,
	   sum(qty) as 'cantidad de libros vendidos'
from sales
group by  stor_id  
having sum(qty) >= 100;

/*Ejercicio numero 27*/

select stor_id as tienda,
	   title_id as libro,
	   sum(qty) as 'cantidad de libros vendidos'
from sales
group by stor_id, title_id;

select stor_name as tienda,
	   title as libro,
	   qty as 'cantidad de libros vendidos'
from sales
inner join stores on sales.stor_id = stores.stor_id
inner join titles on titles.title_id = sales.title_id;

/*Ejercicio numero 28*/

select type categoria,
	   truncate(avg(price), 2) promedio
from titles
group by type
having promedio >= 12 and promedio <= 14
order by price;

/*Ejercicio numero 29*/

select type categorias,
	   max(price) 'libro mas caro',
       min(price) 'libro mas barato',
       count(title) 'cantidad de libros'
from titles
group by type
having min(price) < 10 and count(title) > 2;

/*Ejercicio numero 30*/

select count(emp_id) 'cantidad de empleados en la compañia'
from employee;

/*Ejercicio numero 31*/

select *
from titles t
inner join publishers p
on t.pub_id = p.pub_id;
 
/*Ejercicio numero 32*/
select title titulo, pub_name editorial, country
from titles t 
inner join publishers p
on t.pub_id = p.pub_id
where country = 'USA';


/*Ejercicio numero 33*/

select concat( au_fname,' ', au_lname) 'nombre del autor', stor_name 'nombre de la editorial'
from authors a
inner join stores s
on  s.state = a.state
order by 1;

/*Ejercicio numero 34*/

select concat( au_fname,' ', au_lname) 'nombre del autor', title libro
from authors a
inner join titleauthor ta
on a.au_id = ta.au_id
inner join titles t 
on t.title_id = ta.title_id
order by 1;

/*Ejercicio numero 35*/

select concat('El Libro ',title,' fue escrito por ',au_fname,' ', au_lname,' y publicado por la editorial ',pub_name) consulta
from authors a
inner join titleauthor ta on a.au_id = ta.au_id
inner join titles t on t.title_id = ta.title_id
inner join publishers p on p.pub_id = t.pub_id;


/*Ejercicio numero 36*/

select p.pub_name
from publishers p 
left join titles t 
on p.pub_id = t.pub_id
where t.pub_id is null;

/*Ejercicio numero 37*/

select t.title
from titles t
left join sales s
on t.title_id = s.title_id
where s.title_id is null;

/*Ejercicio numero 38*/
select concat(e.fname,' ',e.lname) nombre, j.job_desc descripcion
from employee e
inner join jobs j
on e.job_id = j.job_id
where e.job_lvl between j.min_lvl and j.max_lvl;


/*Ejercicio numero 39*/

select t.title libros, s.stor_name tiendas, type 
from titles t
cross join stores s
where type = 'business' and s.state = 'CA'
order by 2;

/*Ejercicio numero 40*/

select city as ciudades from authors
union
select city as ciudades from publishers
union
select city as ciudades from stores;



select * from sales;


